//
//  NewsCollectionViewCell.swift
//  GCNetwork
//
//  Created by Tyree Pearson on 4/10/18.
//  Copyright © 2018 Tyree Pearson. All rights reserved.
//

import UIKit

class NewsCollectionViewCell: UICollectionViewCell {

    
    
    
    class FeedCell: UICollectionViewCell{
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            setupViews()
            
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        var nameLabel: UILabel{
            let label = UILabel()
            label.text = "Sample"
            label.font = UIFont.boldSystemFont(ofSize: 14)
            label.translatesAutoresizingMaskIntoConstraints = false
            return label
        }
        
        
        
        func setupViews() {
            backgroundColor = UIColor.white
            
            addSubview(nameLabel)
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[v0]|", options: [NSLayoutFormatOptions()], metrics: nil, views: ["v0": nameLabel]))
            
            
        }
    }
}
