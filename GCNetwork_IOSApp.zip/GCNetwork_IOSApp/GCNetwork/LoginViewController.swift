//
//  LoginViewController.swift
//  GCNetwork
//
//  Created by Tyree Pearson on 3/23/18.
//  Copyright © 2018 Tyree Pearson. All rights reserved.
//

import UIKit
import Foundation
import FacebookLogin
import FacebookCore
import FBSDKCoreKit
import FBSDKLoginKit

class LoginViewController: UIViewController, FBSDKLoginButtonDelegate {
    
    
    
    @IBOutlet weak var startLogo: UIImageView!
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    let token : String = ""
    var jsonData : [String: AnyObject] = [:]
    
    
    @IBAction func facebookLoginButton(_ sender: Any) {
        let fbLoginManger : FBSDKLoginManager = FBSDKLoginManager()
        fbLoginManger.logIn(withReadPermissions: ["email"], from: self) { (result , error) -> Void in
            if (error == nil){
                let fbLoginResult : FBSDKLoginManagerLoginResult = result!
                // if user cancels the login
                if (result?.isCancelled)!
                {
                    return
                }
                if (fbLoginResult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                }
            }
        }
        
        performSegue(withIdentifier: "fbklogin", sender: self)
    }
    
    
    
    func getFBUserData(){
            print("Fetch user Data")
            let parameters =  ["fields": "id, name, first_name,last_name, picture.type(large), email"]
            FBSDKGraphRequest(graphPath: "me", parameters : parameters).start(completionHandler: { (connection, result, error) in
                if (error != nil)
                {
                    print(error as Any)
                }
                
                print (result ?? [String: String].self)
                let fbResult = result as? NSDictionary
                
                if let email = fbResult!["email"] as? String {
                    print(email)
                }
                if let picture = fbResult!["picture"] as? NSDictionary, let data = picture["data"] as? NSDictionary, let url = data["url"] as? String{
                    print(url)
                }
            })
        
        }
    
    
    // When view controller is first initatied
    override func viewDidLoad() {
        super.viewDidLoad()

      
        //Create Facebook Button
        let loginbtn = FBSDKLoginButton()
        loginbtn.frame = CGRect(x: 0, y: 675, width: view.frame.width, height: 50)
        
        loginbtn.delegate = self
        view.addSubview(loginbtn)
        loginbtn.readPermissions = ["public_profile","email","user_friends"]
        
        // Do any additional setup after loading the view.
        
        //OPAPIServiceManager().getdatawithnotoken(servicename: token) {_,_,_ in self.jsonData}
        //print(self.jsonData)
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //When Facebook Button is Pressed
    //If There is an account it Changes Text
    //Showing Successful Login
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
       // get error from login
        if error != nil
        {
            print(error)
            return
        }
        if (result.token) != nil
        {
            let usertoken = FBSDKAccessToken.current().tokenString as NSString
            let userId = FBSDKAccessToken.current().userID as NSString
            print("Token = \(FBSDKAccessToken.current().tokenString)")
            print ("UserId = \(FBSDKAccessToken.current().userID)")
            print(userId)
            print(usertoken)
        
        }
    
        
        print("Successful Login to Facebook")
    }
    
    
    //Facebook Button Text changes to Logged out
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("Logged out of Facebook")
    }
    override func performSegue(withIdentifier identifier: String, sender: Any?) {
        
    }
    
    
    /*
    struct jsonData {
        let data: String
        let success: String
        
        //for the error create a json serialization
        enum SerializationError: Error {
            case missing(String)
            case invalid(String, Any)
        
        }
        
        init(json:[String:Any]) {
            guard let success = json["success"] as? String else {
                throw SerializationError.missing("success is mssing")
            }
            
            guard let data = json ["data"] as? String else {
                throw SerializationError.missing("data is missing")
            }
            
           self.success = success
           self.data = data
            
            
        }
    }
 */
    
    
    
 
    
    //LOGIN BUTTON
    @IBAction func usrLogin(_ sender: Any) {
        
        //get input from usernameField and passwordField
        // display in textView
       
        
        //parameters for post request
        let parameters = ["email": usernameField.text, "success" : passwordField.text ]
        
        
        guard let url = URL(string: "http://gcnetwork-mvp.mybluemix.net/auth/apikey")
            else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        //read as json application for its content
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //throwing function
        guard let body = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {return}
        request.httpBody = body
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            
            if let response = response {
                print(response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                    
                    
                } catch {
                    print(error)
                }
            }
            }.resume()
        
        
    }
 
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //when touched outside text field tables disappears
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        
        //dismess action and text disapears
        textField.resignFirstResponder()
        return true
    }
}





