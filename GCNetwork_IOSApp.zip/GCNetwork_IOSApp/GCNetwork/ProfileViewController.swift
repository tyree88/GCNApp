//
//  ProfileViewController.swift
//  GCNetwork
//
//  Created by Tyree Pearson on 3/26/18.
//  Copyright © 2018 Tyree Pearson. All rights reserved.
//

import UIKit
import SwiftyJSON
import Foundation

class ProfileViewController: UIViewController {

    //Button to segue to news feeds
    @IBAction func feedBtn(_ sender: Any) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //GET API//
        
        //the json file url
        let url = URL(string: "http://gcnetwork-mvp.mybluemix.net/api/profile/get")
        
        let task = URLSession.shared.dataTask(with: url!, completionHandler:  {(data, response, error) in
            //checks for error
            if error != nil
            {
                print ("Error")
                
            }
            else
            {
                // checks the data from URL
                if let content = data
                {
                    do
                    {
                        // gets vlaues from json and put into json dict
                        let json = try? JSON(data: content)
                        
                        let type = json!["status"]
                        let user = json!["data"]
                        let name = json!["username"][0]
                        print(type)
                        print(user)
                    }
                    catch
                    {
                        
                    }
                }
                
            }
            
       
            
            })
        task.resume()
        
        /*SWIFTYJSON practice
        let animals = "[{\"animal\":{\"type\": \"Cat\",\"legs\":\"4\"},{\"animal\":{\"type\": \"Spider\",\"legs\":\"8\"}}]"
        if let dataFromString = animals.data(using: .utf8, allowLossyConversion: false){
        let animalsJSON = JSON(dataFromString)
        
        let firstanimalLegs = animalsJSON[0]["animals"]["legs"]
        let firstanimalType = animalsJSON[0]["animal"]["type"]
        
        print(firstanimalLegs)
        print(firstanimalType)
        }
         */
        
        
        
        // Do any additional setup after loading the view.
       //self.navigationController?.navigationBar.barTintColor = UIColor.lightGray
        self.navigationController?.navigationBar.isTranslucent = false
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    /*
     JSON SAMPLE CODE
     // Prints Json Array Data
     let myJson: NSArray = try JSONSerialization.jsonObject(with: content, options: .allowFragments) as! NSDictionary{
     //getting json in console
     print(myJson.value(forKey: "data")!)
     
     //getting the data tag from json and putting it into a NSArray
     if let profileData = myJson!.value(forKey: "data") as? NSArray{
     //looping through all the elements
     for username in profileData {
     //converting the element to a dictionary
     if let dataDict = username as? NSDictionary{
     //getting the username from the diction
     if let name = dataDict.value(forKey: "username"){
     
     //adding the name to the array
     
     }
     }
     }
     }
     
     
     }
     */

}
