//
//  ViewController.swift
//  GCNetwork
//
//  Created by Tyree Pearson on 3/23/18.
//  Copyright © 2018 Tyree Pearson. All rights reserved.
//

import UIKit
import SwiftyJSON
import Foundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        super.viewDidLoad()
        
        //GET API//
        
        //the json file url
        let url = URL(string: "http://gcnetwork-mvp.mybluemix.net/api/profile/get")
        
        let task = URLSession.shared.dataTask(with: url!, completionHandler:  {(data, response, error) in
            //checks for error
            if error != nil
            {
                print ("Error")
                
            }
            else
            {
                // checks the data from URL
                if let content = data
                {
                    do
                    {
                        // gets vlaues from json and put into json dict
                        let json = try? JSON(data: content)
                        
                        let type = json!["status"]
                        let user = json!["status"]["data"][0]
                        
                        print(type)
                        print(user)
                    }
                    catch
                    {
                        
                    }
                }
                
            }
            
            
            
        })
        task.resume()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

