//
//  ViewController.swift
//  GCNetwork
//
//  Created by Tyree Pearson on 3/23/18.
//  Copyright © 2018 Tyree Pearson. All rights reserved.
//

import UIKit
import SwiftyJSON
import Foundation
import FBSDKCoreKit
import FBSDKLoginKit
import FacebookCore
import FacebookLogin



struct Course {
    let id: Int
    let name: String
    let link: String
    let imageURL: String
    
}

class ViewController: UIViewController , FBSDKLoginButtonDelegate{

    

    @IBAction func logginTapped(_ sender: Any) {
     
        
    }
    
    
    @IBAction func onGetTapped(_ sender: Any) {
    
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users" ) else {return}
    
        let session = URLSession.shared
        
        session.dataTask(with: url) { (data, response, error) in
            if let response = response {
                print(response)
            }
            
            if let data = data {
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch{
                    print(error)
                }
                
            }
        }.resume()
    
    }
    
        
    @IBAction func onPostTapped(_ sender: Any) {
        //parameters for post request
        let parameters = ["username": "", "success" : "true" ]
        
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts")
            else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        //read as json application for its content
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //throwing function
        guard let body = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {return}
        request.httpBody = body
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            
            if let response = response {
                print(response)
            }
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                    
                } catch {
                    print(error)
                }
            }
        }.resume()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let loginbtn = FBSDKLoginButton()
        loginbtn.frame = CGRect(x: 0, y: 675, width: view.frame.width, height: 50)
        
        
        loginbtn.delegate = self
        
        view.addSubview(loginbtn)
        
        
    }
    
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if error != nil {
            print(error)
            return
        }
        
        print("Successful Login to Facebook")
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("Logged out of Facebook")
    }
    
  
    
        
    
    
    

}

